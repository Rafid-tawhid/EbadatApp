

package com.abc.sharefilesz.ui.callback;

import androidx.annotation.DrawableRes;

/**

 * date: 9/3/18 11:13 PM
 */
public interface IconProvider
{
    @DrawableRes
    int getIconRes();
}
