

package com.abc.sharefilesz.activity;

import com.abc.sharefilesz.app.Activity;

public class ShareTextActivity extends Activity
{
}
