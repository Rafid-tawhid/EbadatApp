

package com.abc.sharefilesz.callback;

import com.abc.sharefilesz.object.DeviceConnection;

public interface OnConnectionSelectionListener
{
    void onConnectionSelection(DeviceConnection connection);
}
