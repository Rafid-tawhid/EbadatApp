

package com.abc.sharefilesz.object;

public interface Identifiable
{
    Identity getIdentity();
}
