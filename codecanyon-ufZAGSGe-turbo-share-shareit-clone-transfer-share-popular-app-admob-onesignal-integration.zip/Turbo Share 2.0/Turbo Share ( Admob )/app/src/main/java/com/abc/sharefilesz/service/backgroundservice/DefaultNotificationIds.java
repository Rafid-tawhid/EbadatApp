

package com.abc.sharefilesz.service.backgroundservice;

public enum DefaultNotificationIds
{
    ID_BG_DEFAULT_TASKS // Notification representing the tasks with BackgroundTask#TASK_GROUP_DEFAULT
}
