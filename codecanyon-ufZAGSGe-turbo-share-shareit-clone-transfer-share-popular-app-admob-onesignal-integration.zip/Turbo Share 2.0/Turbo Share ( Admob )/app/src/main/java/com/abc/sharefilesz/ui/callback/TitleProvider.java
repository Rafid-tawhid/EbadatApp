

package com.abc.sharefilesz.ui.callback;

import android.content.Context;

public interface TitleProvider
{
    CharSequence getDistinctiveTitle(Context context);
}
