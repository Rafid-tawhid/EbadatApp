

package com.abc.sharefilesz.adapter;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.ColorInt;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.drawable.DrawableCompat;
import androidx.core.widget.ImageViewCompat;

import com.abc.sharefilesz.object.IndexOfTransferGroup;
import com.abc.sharefilesz.widget.GroupEditableListAdapter;
import com.abc.sharefilesz.R;
import com.abc.sharefilesz.app.IEditableListFragment;
import com.abc.sharefilesz.database.Kuick;
import com.abc.sharefilesz.util.AppUtils;
import com.abc.sharefilesz.util.FileUtils;
import com.abc.sharefilesz.util.TransferUtils;
import com.genonbeta.android.database.SQLQuery;
import com.genonbeta.android.framework.util.listing.Merger;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;

/**

 * date: 9.11.2017 23:39
 */

public class TransferGroupListAdapter extends GroupEditableListAdapter<IndexOfTransferGroup,
        GroupEditableListAdapter.GroupViewHolder>
{
    private final List<Long> mRunningTasks = new ArrayList<>();
    private NumberFormat mPercentFormat;

    @ColorInt
    private int mColorPending;
    private int mColorDone;
    private int mColorError;

    public TransferGroupListAdapter(IEditableListFragment<IndexOfTransferGroup, GroupViewHolder> fragment)
    {
        super(fragment, MODE_GROUP_BY_DATE);

        Context context = getContext();
        mPercentFormat = NumberFormat.getPercentInstance();
        mColorPending = ContextCompat.getColor(context, AppUtils.getReference(context, R.attr.colorControlNormal));
        mColorDone = ContextCompat.getColor(context, AppUtils.getReference(context, R.attr.colorAccent));
        mColorError = ContextCompat.getColor(context, AppUtils.getReference(context, R.attr.colorError));
    }

    @Override
    protected void onLoad(GroupLister<IndexOfTransferGroup> lister)
    {
        List<Long> activeList = new ArrayList<>(mRunningTasks);

        for (IndexOfTransferGroup index : AppUtils.getKuick(getContext()).castQuery(
                new SQLQuery.Select(Kuick.TABLE_TRANSFERGROUP), IndexOfTransferGroup.class)) {
            TransferUtils.loadGroupInfo(getContext(), index);
            index.isRunning = activeList.contains(index.group.id);

            lister.offerObliged(this, index);
        }
    }

    @Override
    protected IndexOfTransferGroup onGenerateRepresentative(String text, Merger<IndexOfTransferGroup> merger)
    {
        return new IndexOfTransferGroup(text);
    }

    @NonNull
    @Override
    public GroupEditableListAdapter.GroupViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        GroupViewHolder holder = viewType == VIEW_TYPE_DEFAULT ? new GroupViewHolder(getInflater().inflate(
                R.layout.list_transfer_group, parent, false)) : createDefaultViews(parent, viewType,
                true);

        if (!holder.isRepresentative()) {
            getFragment().registerLayoutViewClicks(holder);
            holder.itemView.findViewById(R.id.layout_image)
                    .setOnClickListener(v -> getFragment().setItemSelected(holder, true));
        }

        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull final GroupEditableListAdapter.GroupViewHolder holder, int position)
    {
        try {
            final IndexOfTransferGroup object = getItem(position);

            if (!holder.tryBinding(object)) {
                final View parentView = holder.itemView;
                @ColorInt
                int appliedColor;
                int percentage = (int) (object.percentage() * 100);
                String assigneesText = object.getAssigneesAsTitle(getContext());
                ProgressBar progressBar = parentView.findViewById(R.id.progressBar);
                ImageView image = parentView.findViewById(R.id.image);
                View statusLayoutWeb = parentView.findViewById(R.id.statusLayoutWeb);
                TextView text1 = parentView.findViewById(R.id.text);
                TextView text2 = parentView.findViewById(R.id.text2);
                TextView text3 = parentView.findViewById(R.id.text3);
                TextView text4 = parentView.findViewById(R.id.text4);

                parentView.setSelected(object.isSelectableSelected());

                if (object.hasIssues)
                    appliedColor = mColorError;
                else
                    appliedColor = object.numberOfCompleted() == object.numberOfTotal() ? mColorDone : mColorPending;

                if (object.isRunning) {
                    image.setImageResource(R.drawable.ic_pause_white_24dp);
                } else {
                    if (object.hasOutgoing() == object.hasIncoming())
                        image.setImageResource(object.hasOutgoing()
                                ? R.drawable.ic_compare_arrows_white_24dp
                                : R.drawable.ic_error_outline_white_24dp);
                    else
                        image.setImageResource(object.hasOutgoing()
                                ? R.drawable.ic_arrow_up_white_24dp
                                : R.drawable.ic_arrow_down_white_24dp);
                }

                statusLayoutWeb.setVisibility(object.hasOutgoing() && object.group.isServedOnWeb ? View.VISIBLE
                        : View.GONE);
                text1.setText(FileUtils.sizeExpression(object.bytesTotal(), false));
                text2.setText(assigneesText.length() > 0 ? assigneesText : getContext().getString(
                        object.group.isServedOnWeb ? R.string.text_transferSharedOnBrowser : R.string.text_emptySymbol));
                text3.setText(mPercentFormat.format(object.percentage()));
                text4.setText(getContext().getString(R.string.text_transferStatusFiles,
                        object.numberOfCompleted(), object.numberOfTotal()));
                progressBar.setMax(100);
                if (Build.VERSION.SDK_INT >= 24)
                    progressBar.setProgress(percentage <= 0 ? 1 : percentage, true);
                else
                    progressBar.setProgress(percentage <= 0 ? 1 : percentage);
                ImageViewCompat.setImageTintList(image, ColorStateList.valueOf(appliedColor));
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
                    Drawable wrapDrawable = DrawableCompat.wrap(progressBar.getProgressDrawable());

                    DrawableCompat.setTint(wrapDrawable, appliedColor);
                    progressBar.setProgressDrawable(DrawableCompat.unwrap(wrapDrawable));
                } else
                    progressBar.setProgressTintList(ColorStateList.valueOf(appliedColor));
            }
        } catch (Exception ignored) {
        }
    }

    public void updateActiveList(List<Long> list)
    {
        synchronized (mRunningTasks) {
            mRunningTasks.clear();
            mRunningTasks.addAll(list);
        }
    }
}
