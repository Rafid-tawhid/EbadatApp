

package com.abc.sharefilesz.activity;

import com.abc.sharefilesz.app.Activity;

public class SearchActivity extends Activity
{
}
