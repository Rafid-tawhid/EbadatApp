

package com.abc.sharefilesz.activity;

import android.os.Bundle;
import androidx.annotation.Nullable;
import com.abc.sharefilesz.app.Activity;

public class PickBestConnectionActivity extends Activity
{
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
    }
}
