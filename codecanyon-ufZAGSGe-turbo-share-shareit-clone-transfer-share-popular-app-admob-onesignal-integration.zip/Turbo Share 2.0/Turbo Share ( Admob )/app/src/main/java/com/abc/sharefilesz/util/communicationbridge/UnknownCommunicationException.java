

package com.abc.sharefilesz.util.communicationbridge;

public class UnknownCommunicationException extends CommunicationException
{
    public UnknownCommunicationException()
    {
        super();
    }
}
