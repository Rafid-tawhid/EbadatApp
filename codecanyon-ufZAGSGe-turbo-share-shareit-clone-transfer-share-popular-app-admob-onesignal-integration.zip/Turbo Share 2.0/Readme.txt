Hi !

Thanks for your purchase. In this version we haven't updated Facebook ads version yet. Please use Free ads version or Admob Ads version. 

Regards,
Pharid